# Sonde Themes — the whole shooting match

Every file in this zip is a plain CSS stylesheet. There is no build step and
no runtime to install. Link the ones you want from your HTML and you're done.

## Files

- `tokens.css` — Layer 1. 57 CSS custom properties (`--sonde-color-*`,
  `--sonde-font-*`, `--sonde-motion-*`, `--sonde-content-*`) with
  contrast-corrected light-mode defaults plus locale-aware overrides for
  CJK readable line length.
- `daylight.css` — Layer 2 override palette for the `daylight` theme.
- `ultraviolet.css` — Layer 2 override palette for the `ultraviolet` theme.
- `infrared.css` — Layer 2 override palette for the `infrared` theme.
- `high-contrast.css` — Layer 2 override palette for the `high-contrast` theme.

## Usage

```html
<link rel="stylesheet" href="./tokens.css">
<link rel="stylesheet" href="./daylight.css">
```

Every theme passes `sonde cockpit theme-validate --all` at WCAG 2.1 AA. The
high-contrast theme targets AAA (7:1 on every foreground/background pair).
